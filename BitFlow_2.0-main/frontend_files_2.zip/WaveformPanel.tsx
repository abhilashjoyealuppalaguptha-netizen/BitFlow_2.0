/**
 * components/WaveformPanel.tsx — Digital timing diagram renderer
 *
 * Renders VCD signal data as a classic oscilloscope-style timing diagram,
 * entirely with SVG. No external charting library needed.
 *
 * Layout:
 *   ┌──────────────────────────────────────────────────────────────────┐
 *   │ ◈ WAVEFORM  3 signals · 1ns  ·  0 → 210ns          [download]   │ ← header
 *   ├──────────────┬───────────────────────────────────────────────────┤
 *   │              │  0   10   20   30  ...                            │ ← time axis
 *   │ clk          │ ┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐                               │
 *   │ rst          │ ┌──────┐                                          │
 *   │ count   [4]  │ ╱ 0 ╲╱ 1 ╲╱ 2 ╲╱ 3 ╲╱                          │
 *   └──────────────┴───────────────────────────────────────────────────┘
 *
 * Architecture:
 *   • Fixed left column (HTML divs) for signal labels — always visible
 *   • Horizontally scrollable SVG for waveforms — scrolls independently
 *   • Both share the same row height constant so rows align perfectly
 *
 * Rendering rules:
 *   • 1-bit signals (clk, rst, en): phosphor-green step function
 *   • Multi-bit signals (count[3:0]): blue hexagonal bus segments with hex labels
 *   • Unknown/Hi-Z (x, z): grey dashed midline
 *
 * Props:
 *   parsedVcd — output of parseVcd() from lib/vcd-parser.ts
 *   onDownload — called when the download button is clicked
 */

"use client";

import React, { useRef, useState } from "react";
import type { ParsedVcd, VcdSignal } from "@/lib/vcd-parser";
import { binToHex, niceTimeStep } from "@/lib/vcd-parser";
import { downloadVcd } from "@/lib/api";
import type { SimulateResponse } from "@/lib/types";

// ─────────────────────────────────────────────────────────────────────────────
// Layout constants — change these to tune the diagram geometry
// ─────────────────────────────────────────────────────────────────────────────

const LABEL_W   = 136;  // px — fixed left label column width
const ROW_H     = 40;   // px — height of each signal row
const AXIS_H    = 26;   // px — time axis height above first signal row
const SIG_PAD   = 8;    // px — vertical padding inside each row (high/low margin)
const PAD_RIGHT = 24;   // px — extra space after the last timestamp
const CROSS_W   = 5;    // px — half-width of bus transition chevrons
/** Target SVG width before horizontal scrolling kicks in. */
const TARGET_W  = 880;

// ─────────────────────────────────────────────────────────────────────────────
// Props
// ─────────────────────────────────────────────────────────────────────────────

interface WaveformPanelProps {
  parsedVcd: ParsedVcd;
  result:    SimulateResponse;      // needed for download button
}

// ─────────────────────────────────────────────────────────────────────────────
// Empty state
// ─────────────────────────────────────────────────────────────────────────────

function EmptyState() {
  return (
    <div className="flex flex-1 items-center justify-center text-[12px] font-mono text-dim">
      <div className="text-center space-y-1">
        <div className="text-2xl text-dim/40">∿</div>
        <div>No signals found in waveform.</div>
        <div className="text-[11px]">
          Make sure your testbench calls{" "}
          <span className="text-pale">$dumpfile</span> and{" "}
          <span className="text-pale">$dumpvars</span>.
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Signal label row (left column)
// ─────────────────────────────────────────────────────────────────────────────

function SignalLabel({ sig }: { sig: VcdSignal }) {
  const isBus = sig.width > 1;
  return (
    <div
      className="flex items-center justify-between px-3 border-b border-rim/30 shrink-0"
      style={{ height: ROW_H }}
    >
      <span
        className="font-mono text-[11px] text-pale truncate"
        title={sig.name}
      >
        {sig.name}
      </span>
      {isBus && (
        <span className="font-mono text-[9px] text-dim ml-1 shrink-0">
          [{sig.width}]
        </span>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Waveform SVG rendering helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Render a 1-bit signal as a phosphor-green step function.
 *
 * Algorithm:
 *   Start at (0, y based on first change value or midline).
 *   For each change event: H (horizontal) to change time, V (vertical) to new level.
 *   Finally H to the end of the chart.
 *
 *   The SVG H/V path commands make this compact and readable.
 */
function render1bit(
  sig: VcdSignal,
  ri: number,
  xOf: (t: number) => number,
  chartW: number,
): React.ReactElement {
  const yH = ri * ROW_H + AXIS_H + SIG_PAD;         // y when high (1)
  const yL = ri * ROW_H + AXIS_H + ROW_H - SIG_PAD; // y when low  (0)
  const yX = (yH + yL) / 2;                          // y when unknown

  const toY = (v: string): number => {
    if (v === "1") return yH;
    if (v === "0") return yL;
    return yX; // 'x', 'z', or anything else
  };

  const changes = sig.changes;

  // ── No data at all ────────────────────────────────────────────────────────
  if (changes.length === 0) {
    return (
      <line
        key={sig.id}
        x1={0}
        y1={yX}
        x2={chartW}
        y2={yX}
        stroke="#4a4d60"
        strokeWidth={1}
        strokeDasharray="4 3"
      />
    );
  }

  // ── Build SVG path using H/V commands ─────────────────────────────────────
  const firstChange = changes[0];

  // Initial y: use first change value if it starts at t=0, else midline
  const startY = firstChange.time === 0 ? toY(firstChange.value) : yX;
  let d = `M 0 ${startY}`;

  for (let j = 0; j < changes.length; j++) {
    const { time, value } = changes[j];

    if (j === 0 && time === 0) {
      // Already positioned at the correct y via `M 0 ${startY}` above.
      // Do nothing here — the H command below will extend to next change.
    } else {
      // Horizontal line to this change time, then vertical to new value.
      d += ` H ${xOf(time)} V ${toY(value)}`;
    }
  }

  // Extend the last value to the end of the chart.
  d += ` H ${chartW}`;

  // ── Unknown/hi-z overlay ──────────────────────────────────────────────────
  // If any changes have x/z values, draw a separate grey indicator.
  const hasUnknown = changes.some((c) => c.value === "x" || c.value === "z");

  return (
    <g key={sig.id}>
      <path
        d={d}
        stroke="#00e87a"
        fill="none"
        strokeWidth={1.5}
        strokeLinejoin="round"
      />
      {/* Subtle fill under the high segments for readability */}
      <path
        d={`${d} V ${yL} H 0 Z`}
        fill="rgba(0,232,122,0.04)"
        stroke="none"
      />
    </g>
  );
}

/**
 * Render a multi-bit (bus) signal as hexagonal segments with hex value labels.
 *
 * Each stable region is drawn as a hexagon (parallelogram-like shape):
 *
 *   x1,yM ─── x1+CW,yH ────────── x2-CW,yH ─── x2,yM
 *           \                                  /
 *   x1,yM ─── x1+CW,yL ────────── x2-CW,yL ─── x2,yM
 *
 * The hex value is printed in the centre of each stable region.
 */
function renderBus(
  sig: VcdSignal,
  ri: number,
  xOf: (t: number) => number,
  chartW: number,
  maxTime: number,
): React.ReactElement {
  const yH = ri * ROW_H + AXIS_H + SIG_PAD;
  const yL = ri * ROW_H + AXIS_H + ROW_H - SIG_PAD;
  const yM = (yH + yL) / 2;

  if (sig.changes.length === 0) {
    // No data — flat unknown bar
    return (
      <g key={sig.id}>
        <line x1={0} y1={yH} x2={chartW} y2={yH} stroke="#4a4d60" strokeWidth={1} strokeDasharray="4 3" />
        <line x1={0} y1={yL} x2={chartW} y2={yL} stroke="#4a4d60" strokeWidth={1} strokeDasharray="4 3" />
        <text x={chartW / 2} y={yM + 4} textAnchor="middle" fontSize={10} fill="#4a4d60" fontFamily="monospace">x</text>
      </g>
    );
  }

  // Build stable regions: [(x_start, x_end, value), ...]
  const regions = sig.changes.map((change, idx) => ({
    x1:    xOf(change.time),
    x2:    idx + 1 < sig.changes.length ? xOf(sig.changes[idx + 1].time) : chartW,
    value: change.value,
  }));

  return (
    <g key={sig.id}>
      {regions.map((reg, idx) => {
        const { x1, x2, value } = reg;
        const label = binToHex(value);
        const isUnknown = label === "x" || label === "z" || label === "X";

        // Left inner x: first region starts flat (no left chevron at x=0)
        const lx = x1 === 0 ? 0 : x1 + CROSS_W;
        // Right inner x: last region ends flat at chart edge
        const rx = x2 === chartW ? chartW : x2 - CROSS_W;

        // Hexagonal polygon points (clockwise from left point)
        const pts = [
          `${x1},${yM}`,  // left apex
          `${lx},${yH}`,  // top-left
          `${rx},${yH}`,  // top-right
          `${x2},${yM}`,  // right apex
          `${rx},${yL}`,  // bottom-right
          `${lx},${yL}`,  // bottom-left
        ].join(" ");

        const fillColour  = isUnknown ? "rgba(74,77,96,0.15)"   : "rgba(77,184,255,0.08)";
        const strokeColour= isUnknown ? "#4a4d60"               : "#4db8ff";
        const textColour  = isUnknown ? "#4a4d60"               : "#4db8ff";

        // Only show text if the region is wide enough
        const regionW = rx - lx;
        const showText = regionW > 16;

        return (
          <g key={idx}>
            <polygon
              points={pts}
              fill={fillColour}
              stroke={strokeColour}
              strokeWidth={1}
            />
            {showText && (
              <text
                x={(lx + rx) / 2}
                y={yM + 4}
                textAnchor="middle"
                fontSize={regionW > 32 ? 10 : 8}
                fill={textColour}
                fontFamily="monospace"
                style={{ userSelect: "none" }}
              >
                {label}
              </text>
            )}
          </g>
        );
      })}
    </g>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main component
// ─────────────────────────────────────────────────────────────────────────────

export default function WaveformPanel({ parsedVcd, result }: WaveformPanelProps) {
  const { signals, maxTime, timescale } = parsedVcd;
  const scrollRef = useRef<HTMLDivElement>(null);

  /**
   * isOpen controls whether the waveform body is visible.
   * Starts open so the diagram appears immediately after a run.
   * The user can collapse it to reclaim vertical space for the editors.
   */
  const [isOpen, setIsOpen] = useState(true);

  // ── Derived geometry ──────────────────────────────────────────────────────

  /**
   * pixels-per-time-unit.
   * Scale so the chart fills TARGET_W when maxTime is small,
   * but allows larger charts to scroll horizontally.
   */
  const pxPerUnit = maxTime > 0 ? Math.max(2, TARGET_W / maxTime) : 4;
  const chartW    = maxTime * pxPerUnit + PAD_RIGHT;
  const svgH      = AXIS_H + signals.length * ROW_H;

  /** Map a VCD timestamp to SVG x coordinate. */
  const xOf = (t: number): number => t * pxPerUnit;

  // ── Time axis ticks ───────────────────────────────────────────────────────

  const step  = niceTimeStep(maxTime);
  const ticks: number[] = [];
  for (let t = 0; t <= maxTime; t += step) ticks.push(t);

  // ── Horizontal grid lines (one per signal row, drawn in SVG) ─────────────

  const rowDividers = signals.map((_, ri) => (
    <line
      key={`div-${ri}`}
      x1={0}
      y1={AXIS_H + (ri + 1) * ROW_H}
      x2={chartW}
      y2={AXIS_H + (ri + 1) * ROW_H}
      stroke="#1a1b22"
      strokeWidth={1}
    />
  ));

  // ── Tick mark vertical grid lines ────────────────────────────────────────

  const tickLines = ticks.map((t) => (
    <line
      key={`tick-${t}`}
      x1={xOf(t)}
      y1={AXIS_H - 4}
      x2={xOf(t)}
      y2={svgH}
      stroke="#1a1b22"
      strokeWidth={1}
    />
  ));

  // ── Time axis labels ──────────────────────────────────────────────────────

  const tickLabels = ticks.map((t) => (
    <g key={`tlabel-${t}`}>
      {/* Tick mark */}
      <line x1={xOf(t)} y1={AXIS_H - 4} x2={xOf(t)} y2={AXIS_H} stroke="#2e3040" strokeWidth={1} />
      {/* Time label — only show if it won't overlap with the previous one */}
      <text
        x={xOf(t) + 3}
        y={AXIS_H - 7}
        fontSize={9}
        fill="#4a4d60"
        fontFamily="monospace"
        style={{ userSelect: "none" }}
      >
        {t}
      </text>
    </g>
  ));

  // ── Per-signal waveforms ──────────────────────────────────────────────────

  const waveforms = signals.map((sig, ri) =>
    sig.width === 1
      ? render1bit(sig, ri, xOf, chartW)
      : renderBus(sig, ri, xOf, chartW, maxTime)
  );

  // ─────────────────────────────────────────────────────────────────────────
  // Render
  // ─────────────────────────────────────────────────────────────────────────

  const hasWaveform = result.waveform.available && result.waveform.vcd_base64;

  return (
    /*
     * Outer wrapper uses flex-col + conditional h-[220px].
     * When collapsed: only the 32px header is visible (auto height).
     * When open:      header + diagram body at fixed 220px.
     * shrink-0 on the parent in page.tsx prevents the editors from expanding
     * into this panel's space.
     */
    <div className={[
      "flex flex-col bg-pit border-t border-rim overflow-hidden transition-all duration-200",
      isOpen ? "h-[220px]" : "h-8",
    ].join(" ")}>

      {/* ── Panel header ───────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between px-3 h-8 shrink-0 bg-surface border-b border-rim">
        <div className="flex items-center gap-3">
          {/* Oscilloscope icon */}
          <svg viewBox="0 0 14 10" className="w-3.5 h-2.5 text-info" fill="none" stroke="currentColor" strokeWidth="1.2">
            <rect x="0.5" y="0.5" width="13" height="9" rx="1" />
            <polyline points="2,5 4,2 6,8 8,3 10,6 12,5" />
          </svg>
          <span className="font-mono text-[10px] text-ghost tracking-widest uppercase">
            Waveform
          </span>
          <span className="font-mono text-[9px] text-dim">
            {signals.length} signal{signals.length !== 1 ? "s" : ""}
          </span>
          <span className="font-mono text-[9px] text-dim">
            · {timescale}
          </span>
          {maxTime > 0 && (
            <span className="font-mono text-[9px] text-dim">
              · 0 → {maxTime}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Download button */}
          {hasWaveform && (
            <button
              onClick={() => downloadVcd(result.waveform.vcd_base64!, "wave.vcd")}
              className={[
                "flex items-center gap-1 px-2 py-0.5",
                "font-mono text-[9px] tracking-wider uppercase",
                "rounded border border-phosphor/30 bg-phosphor/5 text-phosphor/70",
                "hover:bg-phosphor/15 hover:border-phosphor/60 hover:text-phosphor",
                "transition-all duration-100",
              ].join(" ")}
            >
              ↓ wave.vcd
            </button>
          )}

          {/*
           * Collapse / expand toggle.
           * A simple chevron button — pressing it flips isOpen.
           * The chevron direction mirrors the action: ▲ = click to collapse,
           * ▼ = click to expand.
           */}
          <button
            onClick={() => setIsOpen((v) => !v)}
            title={isOpen ? "Collapse waveform panel" : "Expand waveform panel"}
            className="font-mono text-[10px] text-dim hover:text-ghost transition-colors px-1.5 py-0.5 rounded hover:bg-rim/50 select-none"
            aria-label={isOpen ? "Collapse waveform panel" : "Expand waveform panel"}
          >
            {isOpen ? "▲" : "▼"}
          </button>
        </div>
      </div>

      {/* ── Empty state ────────────────────────────────────────────────────── */}
      {isOpen && signals.length === 0 && <EmptyState />}

      {/* ── Diagram ────────────────────────────────────────────────────────── */}
      {isOpen && signals.length > 0 && (
        <div className="flex flex-1 overflow-hidden">

          {/* ── Fixed label column ─────────────────────────────────────────── */}
          {/*
           * This column is NOT in the scrollable area.
           * It uses the same ROW_H constant as the SVG so rows align exactly.
           * The AXIS_H spacer at top matches the SVG time axis height.
           */}
          <div
            className="shrink-0 flex flex-col bg-pit border-r border-rim overflow-hidden"
            style={{ width: LABEL_W }}
          >
            {/* Spacer matching SVG time axis height */}
            <div
              className="shrink-0 border-b border-rim/40 bg-surface/30"
              style={{ height: AXIS_H }}
            >
              {/* "TIME" label in axis spacer */}
              <span className="font-mono text-[8px] text-dim/50 pl-3 leading-[26px]">
                TIME →
              </span>
            </div>

            {/* Signal labels — one per row, same height as SVG rows */}
            {signals.map((sig) => (
              <SignalLabel key={sig.id} sig={sig} />
            ))}
          </div>

          {/* ── Horizontally scrollable SVG ─────────────────────────────────── */}
          {/*
           * overflow-x-auto: horizontal scroll when chart > container width.
           * overflow-y-hidden: no vertical scroll (panel has fixed height).
           * The SVG width is computed from the data, so it may exceed the
           * container and trigger the horizontal scrollbar.
           */}
          <div
            ref={scrollRef}
            className="flex-1 overflow-x-auto overflow-y-hidden"
            style={{ scrollbarWidth: "thin", scrollbarColor: "#22232d transparent" }}
          >
            <svg
              width={Math.max(chartW, 100)}
              height={svgH}
              style={{ display: "block" }}
            >
              {/* ── Background ────────────────────────────────────────────── */}
              <rect x={0} y={0} width={chartW} height={svgH} fill="#0d0e11" />

              {/* ── Time axis background band ─────────────────────────────── */}
              <rect x={0} y={0} width={chartW} height={AXIS_H} fill="#13141a" />

              {/* ── Vertical grid lines at each tick ────────────────────── */}
              {tickLines}

              {/* ── Horizontal row dividers ──────────────────────────────── */}
              {rowDividers}

              {/* ── Time axis labels and tick marks ─────────────────────── */}
              {tickLabels}

              {/* ── Signal waveforms ─────────────────────────────────────── */}
              {waveforms}
            </svg>
          </div>
        </div>
      )}
    </div>
  );
}
