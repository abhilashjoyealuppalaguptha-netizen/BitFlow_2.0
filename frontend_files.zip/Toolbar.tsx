/**
 * components/Toolbar.tsx — Top application bar
 *
 * Contains:
 *   • Branding / logo mark
 *   • "Run Simulation" button (primary action)
 *   • Duration display after a completed run
 *   • Workspace ID (correlates with server logs)
 *
 * The component is purely presentational — all state comes from props.
 * The `onRun` callback is the only action it exposes.
 */

"use client";

import type { RunState, SimulateResponse } from "@/lib/types";

interface ToolbarProps {
  runState:  RunState;
  result:    SimulateResponse | null;
  onRun:     () => void;
}

// ─────────────────────────────────────────────────────────────────────────────
// Sub-components
// ─────────────────────────────────────────────────────────────────────────────

/** Animated dots shown inside the button while running. */
function RunningIndicator() {
  return (
    <span className="flex items-center gap-[3px]">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="w-1 h-1 rounded-full bg-current animate-pulse_soft"
          style={{ animationDelay: `${i * 0.2}s` }}
        />
      ))}
    </span>
  );
}

/** Chip showing elapsed time after a run. */
function DurationChip({ ms }: { ms: number }) {
  const label = ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${Math.round(ms)}ms`;
  return (
    <span className="font-mono text-[11px] text-ghost px-2 py-0.5 rounded bg-surface border border-rim">
      {label}
    </span>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Toolbar
// ─────────────────────────────────────────────────────────────────────────────

export default function Toolbar({ runState, result, onRun }: ToolbarProps) {
  const isRunning = runState === "running";

  return (
    <header className="h-toolbar shrink-0 flex items-center justify-between px-4 bg-surface border-b border-rim z-10">
      {/* ── Left: branding ─────────────────────────────────────────────── */}
      <div className="flex items-center gap-3">
        {/* Phosphor-green circuit-board icon mark */}
        <div className="relative flex items-center justify-center w-7 h-7">
          <div className="absolute inset-0 rounded bg-phosphor/10 border border-phosphor/30" />
          <svg
            viewBox="0 0 16 16"
            className="w-4 h-4 text-phosphor relative z-10"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.2"
          >
            <rect x="3" y="3" width="10" height="10" rx="1" />
            <line x1="3" y1="8" x2="0" y2="8" />
            <line x1="13" y1="8" x2="16" y2="8" />
            <line x1="8" y1="3" x2="8" y2="0" />
            <line x1="8" y1="13" x2="8" y2="16" />
            <circle cx="8" cy="8" r="2" fill="currentColor" stroke="none" />
          </svg>
        </div>

        <div className="flex flex-col leading-none">
          <span className="font-display text-[13px] font-semibold text-bright tracking-wide">
            VERILOG
          </span>
          <span className="font-mono text-[9px] text-dim tracking-[0.2em] uppercase">
            Sandbox
          </span>
        </div>
      </div>

      {/* ── Right: controls ────────────────────────────────────────────── */}
      <div className="flex items-center gap-3">
        {/* Duration from last run */}
        {result && <DurationChip ms={result.duration_ms} />}

        {/* Workspace ID — helps correlate with server logs */}
        {result && (
          <span
            className="hidden sm:block font-mono text-[10px] text-dim"
            title="Workspace ID — matches server log prefix ws=..."
          >
            ws:{result.workspace_id}
          </span>
        )}

        {/* Run button */}
        <button
          onClick={onRun}
          disabled={isRunning}
          aria-label={isRunning ? "Simulation running…" : "Run simulation"}
          className={[
            // Base
            "flex items-center gap-2 px-4 py-1.5 rounded",
            "font-mono text-[12px] font-semibold tracking-widest uppercase",
            "border transition-all duration-150 select-none",
            // State variants
            isRunning
              ? "border-phosphor/30 bg-phosphor/5 text-phosphor/60 cursor-not-allowed"
              : [
                  "border-phosphor/60 bg-phosphor/10 text-phosphor",
                  "hover:bg-phosphor/20 hover:border-phosphor",
                  "active:scale-[0.97]",
                  // Subtle glow on hover
                  "hover:shadow-[0_0_12px_0_rgba(0,232,122,0.25)]",
                ].join(" "),
          ].join(" ")}
        >
          {isRunning ? (
            <>
              <RunningIndicator />
              <span>Simulating</span>
            </>
          ) : (
            <>
              {/* Play triangle */}
              <svg
                viewBox="0 0 10 10"
                className="w-2.5 h-2.5 fill-current"
              >
                <polygon points="1,1 9,5 1,9" />
              </svg>
              <span>Run</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
}
