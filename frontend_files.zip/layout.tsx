/**
 * app/layout.tsx — Root layout
 *
 * In Next.js App Router, layout.tsx wraps every page.
 * This root layout:
 *   • Sets <html> and <body> attributes.
 *   • Applies CSS font variables.
 *   • Sets page metadata (title, description, viewport).
 *   • Imports globals.css (once, at the root).
 *
 * It does NOT add any visible UI — that lives in page.tsx.
 */

import type { Metadata, Viewport } from "next";
import "./globals.css";

// ─────────────────────────────────────────────────────────────────────────────
// Metadata — affects <head> on every page
// ─────────────────────────────────────────────────────────────────────────────

export const metadata: Metadata = {
  title:       "Verilog Sandbox",
  description: "Browser-based Icarus Verilog compiler and simulator.",
  icons: {
    // Simple inline SVG favicon — no extra files needed
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'><rect width='16' height='16' rx='2' fill='%2300e87a'/><circle cx='8' cy='8' r='3' fill='%230d0e11'/></svg>",
  },
};

export const viewport: Viewport = {
  width:        "device-width",
  initialScale: 1,
  // Prevent browser zoom on mobile input focus
  maximumScale: 1,
};

// ─────────────────────────────────────────────────────────────────────────────
// Layout component
// ─────────────────────────────────────────────────────────────────────────────

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="h-full">
      <body className="h-full overflow-hidden bg-void text-bright font-mono antialiased">
        {children}
      </body>
    </html>
  );
}
