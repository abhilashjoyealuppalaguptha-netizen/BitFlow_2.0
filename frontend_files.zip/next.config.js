/** @type {import('next').NextConfig} */
const nextConfig = {
  // Monaco Editor ships its own workers that reference self (browser-only).
  // webpack must not try to bundle them for Node/server environments.
  webpack: (config, { isServer }) => {
    if (isServer) {
      // Exclude monaco-editor from the server bundle entirely.
      // It is only ever imported inside a `dynamic(() => ..., { ssr: false })`
      // wrapper, so this is safe.
      config.externals = [
        ...(config.externals || []),
        { "monaco-editor": "monaco-editor" },
      ];
    }
    return config;
  },

  // Optional: proxy /api/* → FastAPI backend so the browser never
  // makes cross-origin requests in production. In dev, Axios talks
  // directly to 127.0.0.1:8000 (configured in lib/api.ts).
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: "http://127.0.0.1:8000/:path*",
      },
    ];
  },
};

module.exports = nextConfig;
